###############################################################################
# providers.tf
#
# The AWS provider, and the tags applied to everything it creates.
###############################################################################

provider "aws" {
  region = var.region

  default_tags {
    tags = {
      Project      = var.project_name
      DeploymentId = var.deployment_id
      ManagedBy    = "terraform"
    }
  }
}
