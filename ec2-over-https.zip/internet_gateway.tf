###############################################################################
# internet_gateway.tf
#
# Internet gateway - the VPC's route to and from the internet.
###############################################################################

resource "aws_internet_gateway" "main" {
  vpc_id = aws_vpc.main.id

  tags = {
    Name = local.igw_name
  }
}
