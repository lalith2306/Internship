###############################################################################
# variable.tf - stage 3
#
# Every input for the stage. All have working defaults, so `terraform apply`
# runs with no .tfvars file.
###############################################################################

#------------------------------------------------------------------------------
# Naming
#------------------------------------------------------------------------------

variable "project_name" {
  description = "First part of every resource name, e.g. the 'stage3' in stage3-docker-123123."
  type        = string
  default     = "stage3"
}


variable "CheckAcknowledgement" {
  description = "CloudLabs acknowledgement flag (carried over from the CFT parameters)"
  type        = string
  default     = "TRUE"
}

variable "deployment_id" {
  description = "Last part of every resource name, e.g. the '123123' in stage3-docker-123123. Change it to stand up a second, independently named copy of the stage."
  type        = string
  default     = "11092003"

  validation {
    condition     = can(regex("^[a-zA-Z0-9][a-zA-Z0-9-]{0,19}$", var.deployment_id))
    error_message = "deployment_id must be 1-20 characters, start with a letter or digit, and contain only letters, digits and hyphens - it ends up in AWS resource names."
  }
}

#------------------------------------------------------------------------------
# Location and sizing
#------------------------------------------------------------------------------

variable "region" {
  description = "AWS region to deploy into."
  type        = string
  default     = "us-east-1"
}

variable "vpc_cidr" {
  description = "CIDR block for the VPC."
  type        = string
  default     = "10.0.0.0/16"
}

variable "subnet_cidr" {
  description = "CIDR block for the public subnet."
  type        = string
  default     = "10.0.1.0/24"
}

variable "cluster_subnet_cidr" {
  description = "CIDR block for clusterSubnet, the second public subnet. Must sit inside vpc_cidr and not overlap subnet_cidr."
  type        = string
  default     = "10.0.2.0/24"
}

#------------------------------------------------------------------------------
# Standalone resources - created and reported, not used by anything here
#------------------------------------------------------------------------------

variable "task_execution_role_policy_arn" {
  description = "Managed policy attached to TaskExecutionRole."
  type        = string
  default     = "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
}

variable "instance_type" {
  description = "EC2 instance type."
  type        = string
  default     = "t3.micro"
}

variable "root_volume_size" {
  description = "Root EBS volume size in GiB."
  type        = number
  default     = 20
}

#------------------------------------------------------------------------------
# Image
#------------------------------------------------------------------------------

variable "ubuntu_version" {
  description = "Ubuntu release number used in the AMI name filter."
  type        = string
  default     = "24.04"
}

variable "ubuntu_codename" {
  description = "Ubuntu release codename used in the AMI name filter (noble = 24.04, jammy = 22.04)."
  type        = string
  default     = "noble"
}

#------------------------------------------------------------------------------
# Web server
#------------------------------------------------------------------------------

variable "nginx_port" {
  description = "Port nginx listens on, and the port opened in the security group. Leave it at 80 and the site is just http://<public-ip>/; set it to anything else and the URL becomes http://<public-ip>:<port>/."
  type        = number
  default     = 80

  validation {
    condition     = var.nginx_port > 0 && var.nginx_port <= 65535
    error_message = "nginx_port must be a valid TCP port between 1 and 65535."
  }
}

variable "http_allowed_cidr" {
  description = "CIDR block allowed to reach nginx. Defaults to the whole internet so the page opens in any browser."
  type        = string
  default     = "0.0.0.0/0"
}

#------------------------------------------------------------------------------
# SSH password login
#
# WARNING: the password travels inside user_data, which is readable from the
# instance metadata service and the EC2 console, and it is kept in the
# Terraform state. Lab use only.
#------------------------------------------------------------------------------

variable "ssh_user" {
  description = "Login user. This is the Ubuntu AMI's default user, so changing it means the account will not exist unless you create it."
  type        = string
  default     = "ubuntu"
}

variable "ssh_password" {
  description = "Password set for ssh_user, and the one SSH password authentication accepts."
  type        = string
  default     = "Password!123"
  sensitive   = true
}

variable "ssh_allowed_cidr" {
  description = "CIDR block allowed to reach TCP/22. Narrow this to your own IP/32 - the default lets the whole internet try the password."
  type        = string
  default     = "0.0.0.0/0"
}
