###############################################################################
# locals.tf
#
# Derived names. Every resource name is <project>-<thing>-<deployment id>.
###############################################################################

locals {
  # Every resource name is built as <project>-<thing>-<deployment id>,
  # e.g. stage3-docker-123123.
  prefix = var.project_name
  suffix = var.deployment_id

  vpc_name      = "${local.prefix}-vpc-${local.suffix}"
  igw_name      = "${local.prefix}-igw-${local.suffix}"
  subnet_name   = "${local.prefix}-public-subnet-${local.suffix}"
  rt_name       = "${local.prefix}-public-rt-${local.suffix}"
  sg_name       = "${local.prefix}-sg-${local.suffix}"
  instance_name = "${local.prefix}-docker-${local.suffix}"
  root_vol_name = "${local.prefix}-docker-root-${local.suffix}"

  # The standalone resources keep the base names they were specified with,
  # with the deployment id appended like everything else.
  cluster_subnet_name = "clusterSubnet-${local.suffix}"
  cluster_sg_name     = "clusterSecurityGroup-${local.suffix}"
}
