###############################################################################
# ami.tf
#
# The Ubuntu image the instance is launched from.
###############################################################################

#------------------------------------------------------------------------------
# Instance
#------------------------------------------------------------------------------
# Latest Canonical Ubuntu image matching the configured release.
data "aws_ami" "ubuntu" {
  most_recent = true
  owners      = ["099720109477"] # Canonical

  filter {
    name   = "name"
    values = ["ubuntu/images/hvm-ssd*/ubuntu-${var.ubuntu_codename}-${var.ubuntu_version}-amd64-server-*"]
  }

  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}
