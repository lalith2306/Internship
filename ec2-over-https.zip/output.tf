###############################################################################
# output.tf - stage 3
#
#   terraform output                        # everything but the password
#   terraform output -raw ssh_command       # how to log in
#   terraform output -raw ssh_password      # the password itself
###############################################################################

#------------------------------------------------------------------------------
# Naming
#------------------------------------------------------------------------------

output "deployment_id" {
  description = "The id appended to every resource name in this deployment."
  value       = var.deployment_id
}

output "resource_names" {
  description = "The name each resource was given, all ending in the deployment id."
  value = {
    vpc              = local.vpc_name
    internet_gateway = local.igw_name
    subnet           = local.subnet_name
    route_table      = local.rt_name
    security_group   = local.sg_name
    instance         = local.instance_name
  }
}

#------------------------------------------------------------------------------
# Infrastructure
#------------------------------------------------------------------------------

output "vpc_id" {
  description = "Id of the VPC created for this deployment."
  value       = aws_vpc.main.id
}

output "subnet_id" {
  description = "Id of the public subnet the instance sits in."
  value       = aws_subnet.public.id
}

output "security_group_id" {
  description = "Id of the instance's security group."
  value       = aws_security_group.instance.id
}

output "instance_id" {
  description = "Id of the EC2 instance."
  value       = aws_instance.docker.id
}

output "instance_type" {
  description = "Instance type that was launched."
  value       = aws_instance.docker.instance_type
}

output "availability_zone" {
  description = "Availability zone the instance landed in."
  value       = aws_instance.docker.availability_zone
}

output "ami_id" {
  description = "AMI the instance was launched from."
  value       = aws_instance.docker.ami
}

#------------------------------------------------------------------------------
# Access
#------------------------------------------------------------------------------

output "public_ip" {
  description = "Public IP of the instance."
  value       = aws_instance.docker.public_ip
}

output "public_dns" {
  description = "Public DNS name of the instance."
  value       = aws_instance.docker.public_dns
}

output "private_ip" {
  description = "Private IP of the instance inside the VPC."
  value       = aws_instance.docker.private_ip
}

output "nginx_url" {
  description = "Open this in a browser. Port 80 is implicit, any other port is shown explicitly."
  value       = var.nginx_port == 80 ? "http://${aws_instance.docker.public_ip}/" : "http://${aws_instance.docker.public_ip}:${var.nginx_port}/"
}

output "nginx_healthcheck_url" {
  description = "Returns the plain text 'ok' once nginx is up."
  value       = var.nginx_port == 80 ? "http://${aws_instance.docker.public_ip}/healthz" : "http://${aws_instance.docker.public_ip}:${var.nginx_port}/healthz"
}

output "ssh_user" {
  description = "Login user."
  value       = var.ssh_user
}

output "ssh_password" {
  description = "Password for ssh_user. Reveal with: terraform output -raw ssh_password"
  value       = var.ssh_password
  sensitive   = true
}

output "ssh_command" {
  description = "Password login - you will be prompted for the password."
  value       = "ssh ${var.ssh_user}@${aws_instance.docker.public_ip}"
}

#------------------------------------------------------------------------------
# Standalone resources
#
# Created by this stage but not wired into anything in it - reported here only.
#------------------------------------------------------------------------------

output "cluster_subnet_id" {
  description = "Id of clusterSubnet, the second public subnet in the VPC."
  value       = aws_subnet.cluster.id
}

output "cluster_security_group_id" {
  description = "Id of clusterSecurityGroup (HTTPS in from anywhere, IPv4 and IPv6)."
  value       = aws_security_group.cluster.id
}

output "task_execution_role_arn" {
  description = "ARN of the ECS task execution role."
  value       = aws_iam_role.TaskExecutionRole.arn
}

output "task_execution_role_name" {
  description = "Name of the ECS task execution role."
  value       = aws_iam_role.TaskExecutionRole.name
}
