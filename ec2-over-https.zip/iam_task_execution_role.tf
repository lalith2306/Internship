###############################################################################
# iam_task_execution_role.tf
#
# The ECS task execution role, created exactly as supplied and reported in the
# outputs. Nothing in this stage assumes it.
#
# Two things were adapted from the snippet to fit this stage:
#   var.did -> var.deployment_id, which is this stage's existing id variable
#   var.AmazonECSTaskExecutionRolePolicy -> var.task_execution_role_policy_arn,
#   which defaults to the AWS managed policy of that name
#
# The deployment id in the role name matters more than it does elsewhere: IAM
# role names are account-wide, not per-region and not per-VPC, so two
# deployments sharing an id would collide here even in different regions.
###############################################################################

resource "aws_iam_role" "TaskExecutionRole" {
  name = "TaskExecutionRole-${var.deployment_id}"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Principal = {
          Service = ["ecs-tasks.amazonaws.com"]
        }
        Action = "sts:AssumeRole"
      }
    ]
  })

  tags = {
    Name = "TaskExecutionRole-${var.deployment_id}"
  }
}

resource "aws_iam_role_policy_attachment" "task_execution_role_policy" {
  role       = aws_iam_role.TaskExecutionRole.name
  policy_arn = var.task_execution_role_policy_arn
}
