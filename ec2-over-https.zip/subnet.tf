###############################################################################
# subnet.tf
#
# The public subnet, and the AZ lookup that places it.
###############################################################################

data "aws_availability_zones" "available" {
  state = "available"
}

resource "aws_subnet" "public" {
  vpc_id            = aws_vpc.main.id
  cidr_block        = var.subnet_cidr
  availability_zone = data.aws_availability_zones.available.names[0]

  # Gives the instance a public IP, which it needs to reach apt and Docker Hub
  # and which is what you SSH to.
  map_public_ip_on_launch = true

  tags = {
    Name = local.subnet_name
  }
}
