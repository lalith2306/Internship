###############################################################################
# terraform.tfvars - stage 3
#
# Terraform loads this file automatically, so these values override the
# defaults in variable.tf without any -var-file flag.
#
# Every variable is listed, set to the value it would have had anyway, so you
# can see the whole surface in one place and edit what you need.
###############################################################################

#------------------------------------------------------------------------------
# Naming - every resource comes out as <project>-<thing>-<deployment id>,
# e.g. stage3-docker-11092003, clusterSubnet-11092003.
#------------------------------------------------------------------------------

CheckAcknowledgement = "TRUE"

project_name  = "stage3"
deployment_id = "11092003"

#------------------------------------------------------------------------------
# Location and networking
#------------------------------------------------------------------------------

region = "us-east-1"

vpc_cidr            = "10.0.0.0/16"
subnet_cidr         = "10.0.1.0/24" # the instance's public subnet
cluster_subnet_cidr = "10.0.2.0/24" # clusterSubnet - created, not used here

#------------------------------------------------------------------------------
# Compute and image
#------------------------------------------------------------------------------

instance_type    = "t3.micro"
root_volume_size = 20

ubuntu_version  = "24.04"
ubuntu_codename = "noble" # must match the version above

#------------------------------------------------------------------------------
# Web server
#------------------------------------------------------------------------------

nginx_port        = 80 # 80 means the site is just http://<public-ip>/
http_allowed_cidr = "0.0.0.0/0"

#------------------------------------------------------------------------------
# SSH password login
#
# Both of these are worth changing. The password is carried in user_data,
# which is readable from the instance metadata service and the EC2 console,
# and ssh_allowed_cidr currently lets the whole internet try it. Narrowing it
# to your own address is a one-line change:
#
#   ssh_allowed_cidr = "203.0.113.25/32"
#------------------------------------------------------------------------------

ssh_user         = "ubuntu"
ssh_password     = "Password!123"
ssh_allowed_cidr = "0.0.0.0/0"

#------------------------------------------------------------------------------
# Standalone resources - created and reported, not used by anything here
#------------------------------------------------------------------------------

task_execution_role_policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
