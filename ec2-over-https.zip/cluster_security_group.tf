###############################################################################
# cluster_security_group.tf
#
# A standalone security group for later use by a cluster: HTTPS in from
# anywhere, over both IPv4 and IPv6.
#
# Nothing in this stage attaches it - the EC2 instance keeps
# aws_security_group.instance. It exists only to be created and reported.
#
# Note on egress: the supplied config listed ingress only. AWS adds an
# allow-all egress rule to every new security group, but Terraform strips it
# unless the rule is declared, which would leave this group unable to make any
# outbound connection. The two egress rules below restore AWS's default and
# match the other groups in the supplied snippet. Delete them if the group is
# genuinely meant to have no egress.
###############################################################################

resource "aws_security_group" "cluster" {
  name        = local.cluster_sg_name
  description = "HTTPS inbound from anywhere, IPv4 and IPv6"
  vpc_id      = aws_vpc.main.id

  tags = {
    Name = local.cluster_sg_name
  }
}

resource "aws_vpc_security_group_ingress_rule" "cluster_https_ipv4" {
  security_group_id = aws_security_group.cluster.id
  description       = "HTTPS from anywhere (IPv4)"
  cidr_ipv4         = "0.0.0.0/0"
  from_port         = 443
  to_port           = 443
  ip_protocol       = "tcp"

  tags = {
    Name = "clusterSecurityGroup-https-ipv4-${local.suffix}"
  }
}

resource "aws_vpc_security_group_ingress_rule" "cluster_https_ipv6" {
  security_group_id = aws_security_group.cluster.id
  description       = "HTTPS from anywhere (IPv6)"
  cidr_ipv6         = "::/0"
  from_port         = 443
  to_port           = 443
  ip_protocol       = "tcp"

  tags = {
    Name = "clusterSecurityGroup-https-ipv6-${local.suffix}"
  }
}

resource "aws_vpc_security_group_egress_rule" "cluster_all_ipv4" {
  security_group_id = aws_security_group.cluster.id
  description       = "Allow all outbound (IPv4)"
  cidr_ipv4         = "0.0.0.0/0"
  ip_protocol       = "-1"

  tags = {
    Name = "clusterSecurityGroup-all-out-ipv4-${local.suffix}"
  }
}

resource "aws_vpc_security_group_egress_rule" "cluster_all_ipv6" {
  security_group_id = aws_security_group.cluster.id
  description       = "Allow all outbound (IPv6)"
  cidr_ipv6         = "::/0"
  ip_protocol       = "-1"

  tags = {
    Name = "clusterSecurityGroup-all-out-ipv6-${local.suffix}"
  }
}
