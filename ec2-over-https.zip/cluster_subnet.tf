###############################################################################
# cluster_subnet.tf
#
# A second public subnet in the same VPC, for later use by a cluster.
#
# Nothing in this stage consumes it - the EC2 instance stays in
# aws_subnet.public. It exists only to be created and reported in the outputs.
#
# It is associated with the existing public route table, because a subnet with
# no route to the internet gateway would not actually be public. It is placed
# in the second availability zone, which is the usual reason for wanting a
# second subnet at all; change the index to [0] to keep it alongside the
# instance.
###############################################################################

resource "aws_subnet" "cluster" {
  vpc_id                  = aws_vpc.main.id
  cidr_block              = var.cluster_subnet_cidr
  availability_zone       = data.aws_availability_zones.available.names[1]
  map_public_ip_on_launch = true

  tags = {
    Name = local.cluster_subnet_name
  }
}

resource "aws_route_table_association" "cluster" {
  subnet_id      = aws_subnet.cluster.id
  route_table_id = aws_route_table.public.id
}
