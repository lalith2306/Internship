###############################################################################
# security_group.tf
#
# Security group and its rules: SSH and nginx in, everything out.
###############################################################################

#------------------------------------------------------------------------------
# Security group - SSH and nginx in, everything out
#------------------------------------------------------------------------------
resource "aws_security_group" "instance" {
  name        = local.sg_name
  description = "SSH + nginx inbound, all outbound - ${local.instance_name}"
  vpc_id      = aws_vpc.main.id

  tags = {
    Name = local.sg_name
  }
}

resource "aws_vpc_security_group_ingress_rule" "ssh" {
  security_group_id = aws_security_group.instance.id
  description       = "SSH - password login"
  cidr_ipv4         = var.ssh_allowed_cidr
  from_port         = 22
  to_port           = 22
  ip_protocol       = "tcp"

  tags = {
    Name = "${local.prefix}-ssh-in-${local.suffix}"
  }
}

resource "aws_vpc_security_group_ingress_rule" "nginx" {
  security_group_id = aws_security_group.instance.id
  description       = "nginx - browser access"
  cidr_ipv4         = var.http_allowed_cidr
  from_port         = var.nginx_port
  to_port           = var.nginx_port
  ip_protocol       = "tcp"

  tags = {
    Name = "${local.prefix}-http-in-${local.suffix}"
  }
}

resource "aws_vpc_security_group_egress_rule" "all" {
  security_group_id = aws_security_group.instance.id
  description       = "Allow all outbound (apt + Docker Hub)"
  cidr_ipv4         = "0.0.0.0/0"
  ip_protocol       = "-1"

  tags = {
    Name = "${local.prefix}-all-out-${local.suffix}"
  }
}
