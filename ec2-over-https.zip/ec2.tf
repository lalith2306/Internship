###############################################################################
# ec2.tf
#
# The EC2 instance. Its bootstrap script lives in user_data.tf.
###############################################################################

resource "aws_instance" "docker" {
  ami                    = data.aws_ami.ubuntu.id
  instance_type          = var.instance_type
  subnet_id              = aws_subnet.public.id
  vpc_security_group_ids = [aws_security_group.instance.id]

  root_block_device {
    volume_size           = var.root_volume_size
    volume_type           = "gp3"
    encrypted             = true
    delete_on_termination = true

    tags = {
      Name = local.root_vol_name
    }
  }

  metadata_options {
    http_endpoint               = "enabled"
    http_tokens                 = "required" # IMDSv2 only
    http_put_response_hop_limit = 1
  }

  user_data = local.user_data

  # cloud-init runs user_data on first boot only, so editing user_data.tf
  # has to replace the instance for the change to take effect.
  user_data_replace_on_change = true

  # The instance boots and immediately starts downloading, so the route to the
  # internet gateway has to be in place before it exists - not merely in the
  # same apply.
  depends_on = [aws_route_table_association.public]

  tags = {
    Name = local.instance_name
  }
}
