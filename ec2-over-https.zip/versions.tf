###############################################################################
# versions.tf - stage 3
#
# Terraform and provider version constraints, and the map of this directory.
#
# Stage 3 is the same lab as stage 2 - one Ubuntu EC2 instance with Docker,
# nginx and SSH password login, on its own VPC - with every resource split
# into its own file instead of one main.tf:
#
#   versions.tf           this file: version pins + the map
#   providers.tf          the AWS provider and its default tags
#   variable.tf           every input
#   locals.tf             derived names
#   vpc.tf                the VPC
#   internet_gateway.tf   the internet gateway
#   subnet.tf             the public subnet + AZ lookup
#   route_table.tf        route table + association
#   security_group.tf     the security group and its three rules
#   ami.tf                the Ubuntu image lookup
#   user_data.tf          the cloud-init bootstrap script
#   ec2.tf                the instance
#   output.tf             every result
#
# Resource names are <project>-<thing>-<deployment id>, so the stage can be
# stood up more than once side by side:
#
#   stage3-vpc-123123      stage3-sg-123123
#   stage3-igw-123123      stage3-docker-123123
#
#   VPC -> internet gateway -> public subnet -> route table -> security group
#   -> EC2 instance (Docker + nginx + SSH password auth, set up on first boot)
###############################################################################

terraform {
  required_version = ">= 1.3.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.40.0, < 7.0"
    }
  }
}
