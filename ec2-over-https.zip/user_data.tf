###############################################################################
# user_data.tf
#
# The cloud-init script the instance runs on first boot: Docker, nginx
# and SSH password authentication. Kept out of ec2.tf so the instance
# resource stays readable.
#
# This is a Terraform heredoc, which is also a template - so a shell
# expansion has to be written $${VAR}, not ${VAR}. A single ${...} is a
# Terraform value. Backslashes are NOT escape sequences here, and the
# nested bash heredoc terminators (NGINXCONF, HTMLPAGE, SSHDCONF) must
# end up at column 0 after Terraform strips the <<- indentation.
###############################################################################

locals {
  user_data = <<-EOT
    #!/usr/bin/env bash
    set -euxo pipefail
    export DEBIAN_FRONTEND=noninteractive

    #--------------------------------------------------------------------------
    # Docker Engine, from Docker's official apt repository
    #--------------------------------------------------------------------------
    apt-get update -y
    apt-get install -y ca-certificates curl gnupg

    install -m 0755 -d /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg \
      | gpg --dearmor --yes -o /etc/apt/keyrings/docker.gpg
    chmod a+r /etc/apt/keyrings/docker.gpg

    ARCH="$(dpkg --print-architecture)"
    CODENAME="$(. /etc/os-release && echo "$${UBUNTU_CODENAME:-$VERSION_CODENAME}")"
    echo "deb [arch=$${ARCH} signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $${CODENAME} stable" \
      > /etc/apt/sources.list.d/docker.list

    apt-get update -y
    apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin

    systemctl enable --now docker
    usermod -aG docker ${var.ssh_user}

    docker --version
    # Non-fatal: a transient Docker Hub problem must not stop the rest of this
    # script from running.
    docker run --rm hello-world || true

    #--------------------------------------------------------------------------
    # nginx, listening on port ${var.nginx_port}
    #
    # Both heredocs below are rendered by Terraform BEFORE the instance runs
    # them, so ${var.nginx_port} is already a literal by the time bash sees it.
    # That lets NGINXCONF be quoted, which keeps nginx's own $uri from being
    # eaten by the shell.
    #--------------------------------------------------------------------------
    apt-get install -y nginx

    cat > /etc/nginx/sites-available/default <<'NGINXCONF'
    server {
        listen ${var.nginx_port} default_server;
        listen [::]:${var.nginx_port} default_server;

        root /var/www/html;
        index index.html;
        server_name _;

        location / {
            try_files $uri $uri/ =404;
        }

        location = /healthz {
            access_log off;
            default_type text/plain;
            return 200 "ok\n";
        }
    }
    NGINXCONF

    cat > /var/www/html/index.html <<HTMLPAGE
    <!doctype html><html lang="en"><head><meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>${local.instance_name}</title><style>
    body{font-family:system-ui,sans-serif;background:#0f172a;color:#e2e8f0;padding:3rem 1rem}
    .card{max-width:42rem;margin:0 auto;background:#1e293b;border:1px solid #334155;
    border-radius:12px;padding:2rem}
    table{width:100%;border-collapse:collapse}
    td{padding:.5rem .25rem;border-bottom:1px solid #334155}
    td:first-child{color:#94a3b8;width:40%}
    code,a{color:#7dd3fc}
    </style></head><body><div class="card">
    <h1>${local.instance_name}</h1>
    <p style="color:#94a3b8">nginx on port <code>${var.nginx_port}</code>, installed by cloud-init</p>
    <table>
    <tr><td>Deployment id</td><td><code>${var.deployment_id}</code></td></tr>
    <tr><td>Region</td><td><code>${var.region}</code></td></tr>
    <tr><td>Hostname</td><td><code>$(hostname -f)</code></td></tr>
    <tr><td>OS</td><td><code>$(. /etc/os-release && echo "$PRETTY_NAME")</code></td></tr>
    <tr><td>Kernel</td><td><code>$(uname -r)</code></td></tr>
    <tr><td>Docker</td><td><code>$(docker --version)</code></td></tr>
    <tr><td>Built at</td><td><code>$(date -u '+%F %T UTC')</code></td></tr>
    </table></div></body></html>
    HTMLPAGE

    nginx -t
    systemctl enable --now nginx
    systemctl reload nginx || systemctl restart nginx
    # Non-fatal, like the Docker check: a failed smoke test must not stop the
    # SSH setup below from running.
    curl -fsS -o /dev/null -w 'nginx local check: %%{http_code}\n' "http://127.0.0.1:${var.nginx_port}/" || true

    #--------------------------------------------------------------------------
    # SSH password authentication for ${var.ssh_user}
    #
    # The drop-in is named 00- deliberately: /etc/ssh/sshd_config starts with
    # `Include /etc/ssh/sshd_config.d/*.conf` and sshd keeps the FIRST value it
    # reads for a keyword. Ubuntu cloud images ship 60-cloudimg-settings.conf
    # with `PasswordAuthentication no`, so the override has to sort BEFORE it.
    # A 99- file would silently lose.
    #--------------------------------------------------------------------------
    set +x   # keep the password out of /var/log/cloud-init-output.log
    printf '%s:%s\n' '${var.ssh_user}' '${var.ssh_password}' | chpasswd
    set -x
    passwd -u ${var.ssh_user} || true

    mkdir -p /etc/ssh/sshd_config.d
    cat > /etc/ssh/sshd_config.d/00-password-auth.conf <<'SSHDCONF'
    PasswordAuthentication yes
    PubkeyAuthentication yes
    KbdInteractiveAuthentication no
    UsePAM yes
    PermitRootLogin no
    SSHDCONF
    chmod 644 /etc/ssh/sshd_config.d/00-password-auth.conf

    # Comment out any competing "PasswordAuthentication no" from the image.
    for f in /etc/ssh/sshd_config.d/*.conf /etc/ssh/sshd_config; do
      [ "$f" = /etc/ssh/sshd_config.d/00-password-auth.conf ] && continue
      [ -f "$f" ] || continue
      sed -i -E 's/^[[:space:]]*(PasswordAuthentication[[:space:]]+no)/# \1/I' "$f"
    done

    # Validate before restarting, then restart. Nothing is connected over SSH
    # yet at this point in the boot, so the restart is free.
    /usr/sbin/sshd -t
    systemctl restart ssh.socket || true
    systemctl restart ssh || systemctl restart sshd

    /usr/sbin/sshd -T | grep -i '^passwordauthentication'

    echo "=== ${local.instance_name} ready ==="
  EOT
}
